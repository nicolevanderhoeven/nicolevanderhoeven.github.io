/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5412390029325513, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.27037037037037037, 500, 1500, "57 \/start"], "isController": false}, {"data": [1.0, 500, 1500, "28 \/assets\/application-83a5b9f2e1580179c228e00b1276d04c.css"], "isController": false}, {"data": [0.7969924812030075, 500, 1500, "59 \/code"], "isController": false}, {"data": [0.39855072463768115, 500, 1500, "27 \/"], "isController": false}, {"data": [0.2737226277372263, 500, 1500, "39 \/start"], "isController": false}, {"data": [0.23357664233576642, 500, 1500, "02_Step1_ClickStart"], "isController": true}, {"data": [1.0, 500, 1500, "37 \/assets\/flood_logo_black-2f37da5375643a3756df3dfe52cdb75a.png"], "isController": false}, {"data": [0.27205882352941174, 500, 1500, "04_Step3_SubmitHighestOrderValue"], "isController": true}, {"data": [0.27205882352941174, 500, 1500, "41 \/start"], "isController": false}, {"data": [0.967391304347826, 500, 1500, "29 \/assets\/application-5e48982641645e9e430e258fb10a8f85.js"], "isController": false}, {"data": [1.0, 500, 1500, "33 \/img\/header.png"], "isController": false}, {"data": [0.2631578947368421, 500, 1500, "60 \/start"], "isController": false}, {"data": [1.0, 500, 1500, "38 \/bootstrap\/3.3.0\/css\/bootstrap.min.css"], "isController": false}, {"data": [0.2737226277372263, 500, 1500, "35 \/start"], "isController": false}, {"data": [0.2737226277372263, 500, 1500, "03_Step2_SubmitAge"], "isController": true}, {"data": [1.0, 500, 1500, "34 \/favicon.ico"], "isController": false}, {"data": [0.2631578947368421, 500, 1500, "06_Step5_SubmitOTT"], "isController": true}, {"data": [0.9963768115942029, 500, 1500, "32 \/assets\/tricentis-flood-a1e7e4fbfe3e638b8f61b1ab4460671b.png"], "isController": false}, {"data": [0.24074074074074073, 500, 1500, "05_Step4_ClickNext"], "isController": true}, {"data": [0.0, 500, 1500, "01_HomePage"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1917, 0, 0.0, 780.7083985393848, 17, 3083, 382.0, 1999.0, 2200.0, 2570.2999999999993, 6.355573974305843, 553.4181031133444, 19.604936153128886], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["57 \/start", 135, 0, 0.0, 1579.8962962962967, 987, 2855, 1330.0, 2296.8, 2305.2, 2785.5199999999973, 0.46423339591887264, 79.63929615876954, 3.0908662186814393], "isController": false}, {"data": ["28 \/assets\/application-83a5b9f2e1580179c228e00b1276d04c.css", 138, 0, 0.0, 205.3115942028985, 188, 411, 201.0, 209.0, 215.14999999999995, 401.63999999999965, 0.4645182138264856, 13.18070431732653, 0.467489826041295], "isController": false}, {"data": ["59 \/code", 133, 0, 0.0, 381.98496240601526, 189, 805, 210.0, 702.8000000000001, 707.3, 801.26, 0.46619229555890496, 0.4912319208086508, 0.4573813597567387], "isController": false}, {"data": ["27 \/", 138, 0, 0.0, 1240.768115942029, 806, 2673, 1190.5, 1697.3, 1817.9999999999968, 2663.6399999999994, 0.46098189142874324, 70.65791998936902, 1.760938298575967], "isController": false}, {"data": ["39 \/start", 137, 0, 0.0, 1607.0072992700736, 993, 3083, 1311.0, 2278.2, 2454.7999999999997, 2926.440000000002, 0.46517787111517056, 80.02573413004947, 2.946575265864433], "isController": false}, {"data": ["02_Step1_ClickStart", 137, 0, 0.0, 1804.8613138686135, 1207, 3231, 1574.0, 2522.8, 2712.1, 3193.3800000000006, 0.463823462696067, 91.43443687663142, 3.533939493679136], "isController": true}, {"data": ["37 \/assets\/flood_logo_black-2f37da5375643a3756df3dfe52cdb75a.png", 137, 0, 0.0, 199.59124087591246, 185, 302, 196.0, 204.2, 213.49999999999997, 299.34000000000003, 0.46685181714402546, 3.316745087619908, 0.46807645124465425], "isController": false}, {"data": ["04_Step3_SubmitHighestOrderValue", 136, 0, 0.0, 1578.2794117647063, 992, 2796, 1276.5, 2226.4999999999995, 2398.45, 2722.739999999999, 0.46282431733413193, 79.27462311509692, 3.001704697241431], "isController": true}, {"data": ["41 \/start", 136, 0, 0.0, 1578.2794117647063, 992, 2796, 1276.5, 2226.4999999999995, 2398.45, 2722.739999999999, 0.46282431733413193, 79.27462311509692, 3.001704697241431], "isController": false}, {"data": ["29 \/assets\/application-5e48982641645e9e430e258fb10a8f85.js", 138, 0, 0.0, 326.13768115942037, 198, 635, 384.5, 432.40000000000003, 578.1999999999999, 622.1299999999995, 0.4645166502290606, 48.8994500274334, 0.46023017978140784], "isController": false}, {"data": ["33 \/img\/header.png", 138, 0, 0.0, 209.47101449275368, 189, 400, 200.0, 210.10000000000002, 299.09999999999997, 396.8799999999999, 0.4646808854527945, 21.83727887671814, 0.46719974838203504], "isController": false}, {"data": ["60 \/start", 133, 0, 0.0, 1606.5563909774432, 996, 2800, 1301.0, 2296.2, 2392.6, 2788.44, 0.46517646976527827, 75.60525882764162, 2.9541977968385487], "isController": false}, {"data": ["38 \/bootstrap\/3.3.0\/css\/bootstrap.min.css", 137, 0, 0.0, 30.737226277372265, 17, 215, 25.0, 35.2, 62.19999999999999, 196.38000000000022, 0.4671367585482617, 8.766569422872992, 0.158297319547116], "isController": false}, {"data": ["35 \/start", 137, 0, 0.0, 1574.5328467153279, 996, 3006, 1357.0, 2291.6, 2499.2, 2969.1400000000003, 0.4641534620088697, 79.49133256404978, 2.9137964111112242], "isController": false}, {"data": ["03_Step2_SubmitAge", 137, 0, 0.0, 1607.0072992700736, 993, 3083, 1311.0, 2278.2, 2454.7999999999997, 2926.440000000002, 0.4651762916281849, 80.02546240687985, 2.9465652609231543], "isController": true}, {"data": ["34 \/favicon.ico", 137, 0, 0.0, 198.82481751824815, 186, 355, 194.0, 203.0, 207.99999999999994, 332.58000000000027, 0.4657661853749418, 0.15055528062412668, 0.45197792858988434], "isController": false}, {"data": ["06_Step5_SubmitOTT", 133, 0, 0.0, 1606.5563909774432, 996, 2800, 1301.0, 2296.2, 2392.6, 2788.44, 0.46517646976527827, 75.60525882764162, 2.9541977968385487], "isController": true}, {"data": ["32 \/assets\/tricentis-flood-a1e7e4fbfe3e638b8f61b1ab4460671b.png", 138, 0, 0.0, 210.3188405797101, 186, 818, 194.0, 274.1, 284.15, 619.0999999999924, 0.4645526156332054, 3.3194643443243788, 0.4625341366222312], "isController": false}, {"data": ["05_Step4_ClickNext", 135, 0, 0.0, 1956.2370370370365, 1183, 3358, 1587.0, 2904.0, 3002.4, 3300.759999999998, 0.4642317995343927, 80.12094151796921, 3.5395659819534186], "isController": true}, {"data": ["01_HomePage", 138, 0, 0.0, 2389.405797101449, 1630, 4072, 2262.5, 2899.7000000000003, 3528.2, 3965.139999999996, 0.4597624560643667, 156.95466196631742, 4.037441983100399], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1917, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
